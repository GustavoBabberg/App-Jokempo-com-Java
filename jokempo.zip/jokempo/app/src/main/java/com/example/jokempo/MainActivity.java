package com.example.jokempo;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView escolha, pontosJogador, pontosAdversario, escolhaJogador, pontosJogador2, pontosAdversario2;

    String ia; // pedra, pepel ou tesoura do adversário
    int pontuacaoJogador = 0;
    int pontuacaoAdversario = 0;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        escolha = findViewById(R.id.escolha);
        pontosJogador = findViewById(R.id.pontosJogador);
        pontosAdversario = findViewById(R.id.pontosAdversario);
        pontosAdversario2 = findViewById(R.id.pontosAdversario2);
        pontosJogador2 = findViewById(R.id.pontosJogador2);
        escolhaJogador = findViewById(R.id.escolhaJogador);

    }
    public void programarIA(){
        // Lógica para seleção do adversário
        Random rand = new Random();
        int opcao;
        opcao = rand.nextInt(3); // 0 1 2

        if (opcao == 0){
            ia = "Tesoura";
            escolha.setText(ia);
        } else if (opcao == 1) {
            ia = "Papel";
            escolha.setText(ia);
        }else {
            ia = "Pedra";
            escolha.setText(ia);
        }

    }

    public void clicarPedra(View view) {
        //chamar a opção do adversario
        programarIA();

        if (ia.equals("Tesoura")){
            pontuacaoJogador++;
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosAdversario2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Tesoura");
            pontosJogador.setText("Jogador ganhou");
            pontosAdversario.setText("Adversario perdeu");
        }
        if (ia.equals("Papel")){
            pontuacaoAdversario++;
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosAdversario2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Papel");
            pontosJogador.setText("Jogador perdeu");
            pontosAdversario.setText("Adversario ganhou");
        }
        if (ia.equals("Pedra")){
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosAdversario2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Pedra");
            pontosJogador.setText("Empate");
            pontosAdversario.setText("Empate");
        }
    }

    public void clicarPapel(View view) {
        programarIA();

        if (ia.equals("Pedra")){
            pontuacaoJogador ++;
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosJogador2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Pedra");
            pontosJogador.setText("Jogador ganhou");
            pontosAdversario.setText("Adversario perdeu");
        }
        if (ia.equals("Papel")){
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosJogador2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Papel");
            pontosJogador.setText("Empate");
            pontosAdversario.setText("Empate");
        }
        if (ia.equals("Tesoura")){
            pontuacaoAdversario ++;
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosJogador2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Tesoura");
            pontosJogador.setText("Jogador perdeu");
            pontosAdversario.setText("Adversario ganhou");
        }
    }

    public void clicarTesoura(View view) {
        programarIA();

        if (ia.equals("Pedra")){
            pontuacaoJogador ++;
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosJogador2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Pedra");
            pontosJogador.setText("Jogador ganhou");
            pontosAdversario.setText("Adversario perdeu");
        }
        if (ia.equals("Papel")){
            pontuacaoAdversario ++;
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosJogador2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Papel");
            pontosJogador.setText("Jogador perdeu");
            pontosAdversario.setText("Adversario ganhou");
        }
        if (ia.equals("Tesoura")){
            pontosJogador2.setText("Pontuação Jogador: " + pontuacaoJogador);
            pontosJogador2.setText("Pontuação Adversário: " + pontuacaoAdversario);
            escolhaJogador.setText("Jogador: Tesoura");
            pontosJogador.setText("Empate");
            pontosAdversario.setText("Empate");
        }
    }
}